RIP CORD — POCKET EDITION (iPad + iPhone), Oct 24 2026
========================================================
The rip cord shell, reconfigured for your hands. No account, no cloud,
nothing leaves your devices except what you send to your own server.

WHAT'S IN HERE
- rip-cord-pocket-ipad-2026-10-24.html    the client, iPad-sized
- rip-cord-pocket-iphone-2026-10-24.html  the client, iPhone-sized (safe areas)
- iphone-scaffold/                        the NATIVE iPhone app starting point (Expo)

INSTALL — iPAD / iPHONE (the pocket client, works today)
1. Get this file onto the device (AirDrop, Files app, or open from email).
2. Open it in Safari (from the Files app: tap it, share to Safari, or use the
   share sheet > "Open in Safari").
3. Safari address bar > Share > "Add to Home Screen". Now it's an app with its
   own icon, full screen, no browser bars.
4. First chat needs the network ONCE (to reach your server). Saved chats and
   settings live on the device.

CONNECT (⚙ settings inside the app)
- Engine: Ollama server        Endpoint: http://neo.local:11434   (the Neo, gemma3:4b)
- Same machine as the server:  http://localhost:11434
- REINS PAIRING: Reins can run models on-device (MLX) AND share them on your
  local network as an Ollama- or OpenAI-compatible server. In Reins, turn on
  sharing, copy the address it shows, and either:
    - point THIS client at it in OpenAI-compatible mode, or
    - point Reins at the Neo: add server http://neo.local:11434.
  Either direction works. Your phone and your iPad can also talk to each other.

THE ONE WALL (honest)
Safari on iOS blocks "file://" pages from calling http servers by default and
Ollama only allows origins it knows. If "test + load models" fails from a saved
file, on the server side run:
    launchctl setenv OLLAMA_ORIGINS "*"
(alongside the OLLAMA_HOST=0.0.0.0 the Neo already has). If it still blocks,
serve the file instead of opening it from Files:
    cd to-this-folder && python3 -m http.server 8899
then open http://<this-machine's-ip>:8899/rip-cord-pocket-ipad-2026-10-24.html
in Safari — a served page is a normal origin and always works.

ENGLAND KIT
Drop this whole folder in beside the kit zip. Mac = the vellum-assistant fork
rip cord. iPad = the pocket client. iPhone = pocket client now, native app on
the scaffold. Three cords hanging from the ceiling.
