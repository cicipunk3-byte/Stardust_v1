# RIP CORD — iPhone app scaffold

Native shell for the rip cord on iPhone. Expo + React Native, same shape as the
pinkhaven-mobile lane. It is a SCAFFOLD: the chat screen points at a configurable
Ollama / OpenAI-compatible endpoint (default the Neo) and keeps history on-device.

## Run it
    npm install
    npx expo start

Scan the QR with the Expo Go app on the iPhone. To ship a real installable app
later, it goes through the family Apple dev account (CC's, cicipunk3@icloud.com)
and TestFlight — same road pinkhaven-mobile is already on.

## Files
- App.tsx        the chat screen (endpoint + model pickers, chat view)
- src/config.ts  endpoint defaults — edit here, one place
