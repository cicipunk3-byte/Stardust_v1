import React, { useEffect, useState } from 'react';
import { SafeAreaView, ScrollView, TextInput, Text, TouchableOpacity, View, StyleSheet } from 'react-native';
import { ENDPOINT, MODE } from './src/config';

type Msg = { role: 'user' | 'assistant'; content: string };

export default function App() {
  const [messages, setMessages] = useState<Msg[]>([]);
  const [input, setInput] = useState('');
  const [status, setStatus] = useState('offline pocket client · talks only to ' + ENDPOINT);

  async function send() {
    const t = input.trim();
    if (!t) return;
    const next: Msg[] = [...messages, { role: 'user', content: t }];
    setMessages(next);
    setInput('');
    try {
      const url = MODE === 'ollama' ? ENDPOINT + '/api/chat' : ENDPOINT + '/v1/chat/completions';
      const r = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ model: 'gemma3:4b', messages: next, stream: false }),
      });
      const j = await r.json();
      const out = MODE === 'ollama' ? j.message?.content : j.choices?.[0]?.message?.content;
      setMessages([...next, { role: 'assistant', content: out || '(empty)' }]);
    } catch (e: any) {
      setStatus('send failed: ' + e.message);
    }
  }

  return (
    <SafeAreaView style={s.root}>
      <Text style={s.logo}>⚡ RIP CORD</Text>
      <Text style={s.status}>{status}</Text>
      <ScrollView style={s.chat}>
        {messages.map((m, i) => (
          <View key={i} style={[s.bubble, m.role === 'user' ? s.user : s.bot]}>
            <Text style={s.txt}>{m.content}</Text>
          </View>
        ))}
      </ScrollView>
      <View style={s.row}>
        <TextInput style={s.inp} value={input} onChangeText={setInput} placeholder="type here" placeholderTextColor="#c99ab5" multiline />
        <TouchableOpacity style={s.send} onPress={send}><Text style={s.sendTxt}>↑</Text></TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}

const s = StyleSheet.create({
  root: { flex: 1, backgroundColor: '#12070f', paddingTop: 50, paddingHorizontal: 12 },
  logo: { color: '#ff5fa2', fontWeight: '800', letterSpacing: 2, fontSize: 15 },
  status: { color: '#c99ab5', fontSize: 11, marginBottom: 10 },
  chat: { flex: 1 },
  bubble: { borderRadius: 16, padding: 10, marginVertical: 4, maxWidth: '88%', backgroundColor: '#2a1222' },
  user: { alignSelf: 'flex-end', backgroundColor: '#b8437a' },
  bot: { alignSelf: 'flex-start', borderWidth: 1, borderColor: '#4a2140' },
  txt: { color: '#ffe9f4', fontSize: 15 },
  row: { flexDirection: 'row', alignItems: 'flex-end', marginBottom: 8 },
  inp: { flex: 1, backgroundColor: '#2a1222', borderColor: '#4a2140', borderWidth: 1, borderRadius: 14, color: '#ffe9f4', padding: 10, minHeight: 44 },
  send: { backgroundColor: '#ff5fa2', borderRadius: 14, paddingHorizontal: 18, paddingVertical: 12, marginLeft: 8 },
  sendTxt: { color: '#14050d', fontWeight: '800', fontSize: 16 },
});
