// One place to point the app at your own server.
// Neo:    http://neo.local:11434   (MODE 'ollama')
// Reins:  the address Reins shows when sharing models (MODE 'openai')
export const ENDPOINT = 'http://neo.local:11434';
export const MODE = 'ollama';
